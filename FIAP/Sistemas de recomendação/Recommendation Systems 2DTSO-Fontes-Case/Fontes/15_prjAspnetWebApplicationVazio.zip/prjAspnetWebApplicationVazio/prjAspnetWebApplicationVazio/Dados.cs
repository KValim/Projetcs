﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace prjAspnetWebApplicationVazio
{
    class Dados
    {
        SqlConnection con;
        SqlCommand cmd;
        public DataTable listarClientes()
        {
            try
            {
                conectar();
                con.Open();
                string sql = "SELECT nomeCliente FROM tbCliente";
                SqlCommand adoCmd = new SqlCommand(sql, con);
                //cria um dataadapter
                SqlDataAdapter da = new SqlDataAdapter(adoCmd);
                //cria um objeto datatable
                DataTable dt = new DataTable();
                //preenche o datatable via dataadapter
                da.Fill(dt);
                return dt;
            }
            catch
            {
                throw;
            }
        }
        private void conectar()
        {
            con = new SqlConnection("Data Source=CPX-8F030SWZ5XN\\SQLEXPRESS01;Initial Catalog = DBDINDIN; Integrated Security = True");
        }

        public string consultarClienteMaisSimilar(string clienteOrigem)
        {
            try
            {
                conectar();
                con.Open();
                string sql = "select top 1 a.* from tbClienteSimilaridade a where a.nomeClienteOrigem = '" + clienteOrigem + "' order by similaridade desc;";
                SqlCommand adoCmd = new SqlCommand(sql, con);
                SqlDataReader adoDR = adoCmd.ExecuteReader();
                if (adoDR.HasRows)
                {
                    if (adoDR.Read())
                    {
                        return adoDR["nomeClienteDestino"].ToString();
                    }
                    else
                    {
                        return "";
                    }
                }
                else
                {
                    return "";
                }
            }
            catch
            {
                throw;
            }
        }

        public DataTable listarRecomendacaoOF(string nomeClienteOrigem, string nomeClienteDestino)
        {
            try
            {
                conectar();
                con.Open();
                string sql = "select b.* from tbCliente a, tbClienteProduto b, tbProduto c ";
                sql += "where a.nomeCliente = b.nomeCliente and b.nomeProduto = c.nomeProduto and b.nomeCliente = '" + nomeClienteDestino + "' ";
                sql += "and b.nomeProduto not in (select b.nomeProduto from tbCliente a, tbClienteProduto b, tbProduto c ";
                sql += "where a.nomeCliente = b.nomeCliente and b.nomeProduto = c.nomeProduto ";
                sql += "and b.nomeCliente = '" + nomeClienteOrigem + "')";
                SqlCommand adoCmd = new SqlCommand(sql, con);
                //cria um dataadapter
                SqlDataAdapter da = new SqlDataAdapter(adoCmd);
                //cria um objeto datatable
                DataTable dt = new DataTable();
                //preenche o datatable via dataadapter
                da.Fill(dt);
                return dt;
            }
            catch
            {
                throw;
            }
        }

        public DataTable listarProdutosPopularidade()
        {
            try
            {
                conectar();
                con.Open();
                string sql = "select a.* from tbProduto a order by a.quantidadeLikes desc;";
                SqlCommand adoCmd = new SqlCommand(sql, con);
                //cria um dataadapter
                SqlDataAdapter da = new SqlDataAdapter(adoCmd);
                //cria um objeto datatable
                DataTable dt = new DataTable();
                //preenche o datatable via dataadapter
                da.Fill(dt);
                return dt;
            }
            catch
            {
                throw;
            }
        }

        public bool IncrementarLike(string produto)
        {
            bool retorno = false;
            try
            {
                conectar();
                cmd = new SqlCommand("UPDATE tbProduto SET quantidadeLikes = quantidadeLikes + 1 WHERE nomeProduto = '" + produto + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                retorno = true;
            }
            catch
            {
                retorno = false;
                throw;
            }
            return retorno;
        }

        public bool DecrementarLike(string produto)
        {
            bool retorno = false;
            try
            {
                conectar();
                cmd = new SqlCommand("UPDATE tbProduto SET quantidadeLikes = quantidadeLikes -1 WHERE nomeProduto = '" + produto + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                retorno = true;
            }
            catch
            {
                retorno = false;
                throw;
            }
            return retorno;
        }
      


       

        
     
     }
}